const ADMIN_EMAIL = 'eaglereachmarketing24@gmail.com';
const SPREADSHEET_TITLE = 'Business Award 2026 - Website Enquiries';
const EVENT_NAME = 'Business Award 2026';

function doPost(e) {
  try {
    const p = (e && e.parameter) ? e.parameter : {};
    const formType = String(p.formType || 'Website enquiry');
    const allowed = ['Sponsorship Enquiry', 'Business Award Nomination'];
    if (!allowed.includes(formType)) throw new Error('Unknown form type');
    const lock = LockService.getScriptLock();
    lock.waitLock(15000);
    try {
      const ss = getOrCreateSpreadsheet_();
      const sheet = getOrCreateSheet_(ss, formType);
      const fields = formType === 'Sponsorship Enquiry'
        ? ['Company','Contact person','Mobile','Email','Business category','Package','Website or social link','Objectives']
        : ['Business name','Founder or owner','Mobile','Email','City or district','Year started','Category','Website or social link','Achievements','Reason'];
      if (!p.Mobile || !p.Email) throw new Error('Missing contact details');
      const values = [new Date(), formType, ...fields.map(k => safe_(p[k]))];
      sheet.appendRow(values);
      const sheetUrl = ss.getUrl();
      const subject = '[' + EVENT_NAME + '] New ' + formType;
      const body = 'A new website submission was received.\n\n' +
        fields.map(k => k + ': ' + safe_(p[k])).join('\n') +
        '\n\nReceived: ' + new Date().toString() + '\nGoogle Sheet: ' + sheetUrl;
      MailApp.sendEmail(ADMIN_EMAIL, subject, body);
      return HtmlService.createHtmlOutput('<!doctype html><html><body>Submission received.</body></html>');
    } finally { lock.releaseLock(); }
  } catch (err) {
    MailApp.sendEmail(ADMIN_EMAIL, '[' + EVENT_NAME + '] Website form error', String(err));
    return HtmlService.createHtmlOutput('<!doctype html><html><body>Unable to process submission. Please contact the event team.</body></html>');
  }
}

function getOrCreateSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('SPREADSHEET_ID');
  if (id) return SpreadsheetApp.openById(id);
  const ss = SpreadsheetApp.create(SPREADSHEET_TITLE);
  props.setProperty('SPREADSHEET_ID', ss.getId());
  return ss;
}

function getOrCreateSheet_(ss, formType) {
  const name = formType === 'Sponsorship Enquiry' ? 'Sponsorship Enquiries' : 'Nominations';
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) {
    const fields = formType === 'Sponsorship Enquiry'
      ? ['Company','Contact person','Mobile','Email','Business category','Package','Website or social link','Objectives']
      : ['Business name','Founder or owner','Mobile','Email','City or district','Year started','Category','Website or social link','Achievements','Reason'];
    sheet.appendRow(['Timestamp','Form type', ...fields]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,fields.length+2).setFontWeight('bold').setBackground('#d2a651');
    sheet.autoResizeColumns(1, fields.length+2);
  }
  return sheet;
}

function safe_(value) {
  const s = String(value || '').trim();
  // Prevent spreadsheet formula injection from visitor-supplied text.
  return /^[=+@\-]/.test(s) ? "'" + s : s;
}
